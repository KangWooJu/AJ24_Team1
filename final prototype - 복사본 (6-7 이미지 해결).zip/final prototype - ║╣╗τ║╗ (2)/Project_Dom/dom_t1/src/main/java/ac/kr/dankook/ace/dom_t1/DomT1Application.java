package ac.kr.dankook.ace.dom_t1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DomT1Application {

	public static void main(String[] args) {
		SpringApplication.run(DomT1Application.class, args);
	}

}
