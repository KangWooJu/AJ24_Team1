package ac.kr.dankook.ace.dom_t1.controller;

import java.security.Principal;
import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import ac.kr.dankook.ace.dom_t1.Model.Entity.AuctionRegisterEntity;
import ac.kr.dankook.ace.dom_t1.Model.Entity.SiteuserEntity;
import ac.kr.dankook.ace.dom_t1.Model.Service.AuctionRegisterService;
import ac.kr.dankook.ace.dom_t1.Model.Service.SiteuserService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.data.domain.Page;

import org.springframework.ui.Model;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.server.ResponseStatusException;


@RequiredArgsConstructor
@Controller
public class AuctionListController {

    private final AuctionRegisterService auctionRegisterService;
    private final SiteuserService siteuserService;


    @GetMapping("/DomAuction/list") // 옥션의 리스트를 보여주는 메소드 
    @ResponseBody
    public String list(Model model, @RequestParam(value="page", defaultValue="0") int page) {
        Page<AuctionRegisterEntity> paging = this.auctionRegisterService.getList(page); // 페이지를 받아온 후에 모델에 넘겨주기
        model.addAttribute("paging", paging);
        return "AuctionList";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/DomAuction/detail/{nickname}") // 옥션의 리스트 중 하나를 클릭했을 때 얻을 수 있는 화면 : 상세 페이지
    public String detail(Model model, @PathVariable("nickname") String nickname , AuctionRequestForm auctionRequestForm) {
        AuctionRegisterEntity auctionRegisterEntity = this.auctionRegisterService.getAuctionRegisterEntity(nickname); // 등록Service의 get 메소드 사용 
        model.addAttribute("auctionRegisterEntity",auctionRegisterEntity); // 모델에 넣어주기 
        return "Auction_detail";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/DomAuction/list/create")
    public String auctionRegisterCreate(AuctionRegisterForm auctionRegisterForm){
        return "Auction_create";
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/DomAuction/list/create")
    public String auctionRegisterCreate(@Valid AuctionRegisterForm auctionRegisterForm , BindingResult bindingResult,Principal principal){ 
        if (bindingResult.hasErrors()) { //valid에 맞지 않을 경우 리턴
            return "Auction_create"; // 검증 실패시에 대한 오류 처리 주석 필요 -> 캡쳐화면 참고 부탁드립니다!!
        }
        SiteuserEntity siteuserEntity = this.siteuserService.getUser(principal.getName());
        this.auctionRegisterService.AuctionRegisterCreate(auctionRegisterForm.getTitle(), auctionRegisterForm.getContent(),siteuserEntity); // AuctionRegisterService에 파라미터를 전달하고 메소드 시행 , principal객체를 통해서 사용자명을 얻은 후에 SiteuserEntity를 조회하여 옥션 등록글 저장시에 함께 저장
        return "redirect:/DomAuction/list";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/modify/{nickname}") //게시글 수정 모듈
    public String AuctionRegisterModify(AuctionRegisterForm auctionRegisterForm, @PathVariable("nickname") String nickname, Principal principal)
    {
        AuctionRegisterEntity auctionRegisterEntity = this.auctionRegisterService.getAuctionRegisterEntity(nickname);
        if(!auctionRegisterEntity.getAuthor().getUsername().equals(principal.getName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다."); // 게시글 수정 구현중
        }
        auctionRegisterForm.setTitle(auctionRegisterEntity.getTitle());
        auctionRegisterForm.setContent(auctionRegisterEntity.getContent());
        return "Auction_create";
    }
}
