package ac.kr.dankook.ace.dom_t1.controller;


import lombok.RequiredArgsConstructor;

import java.security.Principal;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;

import ac.kr.dankook.ace.dom_t1.Model.Entity.AuctionRegisterEntity;
import ac.kr.dankook.ace.dom_t1.Model.Entity.SiteuserEntity;
import ac.kr.dankook.ace.dom_t1.Model.Service.AuctionRegisterService;
import ac.kr.dankook.ace.dom_t1.Model.Service.AuctionRequestService;
import ac.kr.dankook.ace.dom_t1.Model.Service.SiteuserService;

@RequestMapping("/request")
@RequiredArgsConstructor
@Controller
public class AuctionRequestController {

    private final AuctionRegisterService auctionRegisterService;
    private final AuctionRequestService auctionRequestService;
    private final SiteuserService siteuserService;

    // 댓글을 작성할 수 있도록 만든 메소드 
    @PreAuthorize("isAuthenticated()") // 로그인된상태 ( isAuthenticated = true 인 상태 ) 에서만 해당 url 사용가능 
    @PostMapping("/create/{nickname}") // URL 요청시에 createRequest 매서드가 호출되도록 @PostMapping 
    public String createRequest(Model model,@PathVariable("nickname") String nickname, @Valid AuctionRequestForm auctionRequestForm, BindingResult bindingResult, Principal principal) // content ( 댓글 내용 ) 를 requestparam으로 넘겨줌 , 시큐리티의 principal 객체 생성 
    {
        AuctionRegisterEntity auctionRegisterEntity = this.auctionRegisterService.getAuctionRegisterEntity(nickname); // nickname 받아오기 
        SiteuserEntity siteuserEntity = this.siteuserService.getUser(principal.getName()); // principal은 siteuserEntity객체의 getUsername() 메소드를 호출
        if (bindingResult.hasErrors()) { //valid 검증에 맞지 않을 경우 예외 처리를 통해 Auction_detial.html 을 출력하도록 한다. 
            model.addAttribute("auctionRegisterEntity", auctionRegisterEntity);
            return "Auction_detail";
        }
        this.auctionRequestService.createRequest(auctionRegisterEntity, auctionRequestForm.getContent(),siteuserEntity);
        return String.format("redirect:/DomAuction/detail/%s",nickname);
    }
    
}
