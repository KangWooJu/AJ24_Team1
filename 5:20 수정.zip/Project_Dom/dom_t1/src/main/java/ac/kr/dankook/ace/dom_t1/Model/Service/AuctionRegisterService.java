package ac.kr.dankook.ace.dom_t1.Model.Service;

import java.util.*;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import ac.kr.dankook.ace.dom_t1.Model.Entity.AuctionRegisterEntity;
import ac.kr.dankook.ace.dom_t1.Model.Entity.SiteuserEntity;
import ac.kr.dankook.ace.dom_t1.Model.repository.AuctionRegisterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;


@RequiredArgsConstructor
@Service
public class AuctionRegisterService {

    private final AuctionRegisterRepository auctionregisterRepository;

    public List<AuctionRegisterEntity> getAuctionRequestEntityList(){ // 게시글 목록 리스트를 조회하여 리턴하는 getList 메서드 
        return this.auctionregisterRepository.findAll(); 
    }


    public AuctionRegisterEntity getAuctionRegisterEntity(String nickname) {  // 데이터가 존재하는지 확인하는 메소드 
        Optional<AuctionRegisterEntity> auctionRegisterEntity = this.auctionregisterRepository.findByNickname(nickname); // nickname으로 등록데이터를 조회 , 예외처리로 등록 물품 미확인 메시지 전달
        if (auctionRegisterEntity.isPresent()) {
            return auctionRegisterEntity.get();
        } else {
            throw new DataNotFoundException("등록 물품이 확인되지 않습니다!");
        }
    }

    public void AuctionRegisterCreate(String title , String content, SiteuserEntity author){
        AuctionRegisterEntity are = new AuctionRegisterEntity(); // AuctionRegisterEntity 의 새로운 객체 are 생성
        are.setTitle(title);
        are.setContent(content);
        are.setCreateDate(LocalDateTime.now());
        are.setAuthor(author); // 작성자 정보 set
        this.auctionregisterRepository.save(are); // 각종 필요한 정보들을 set 한 후에 리포지토리( AuctionRegisterRepository ) 로 넘김 , 그후 CRUD 중 U 시행 
    } 

    public Page<AuctionRegisterEntity> getList(int page) { // 질문 목록을 조회하는 getList 생성 
        List<Sort.Order> sorts = new ArrayList<>();
        sorts.add(Sort.Order.desc("createDate"));
        Pageable pageable = PageRequest.of(page, 10,Sort.by(sorts)); // 조회할 페이지의 개수 및 최신순으로 정렬 
        return this.auctionregisterRepository.findAll(pageable);
    }

    public void modify(AuctionRegisterEntity auctionRegisterEntity,String title,String content)
    {
        auctionRegisterEntity.setTitle(title);
        auctionRegisterEntity.setContent(content);
        auctionRegisterEntity.setModifyDate(LocalDateTime.now());
        this.auctionregisterRepository.save(auctionRegisterEntity);
    }


    
}
