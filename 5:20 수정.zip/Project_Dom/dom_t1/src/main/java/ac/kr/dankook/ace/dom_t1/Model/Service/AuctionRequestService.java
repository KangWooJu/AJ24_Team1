package ac.kr.dankook.ace.dom_t1.Model.Service;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import ac.kr.dankook.ace.dom_t1.Model.Entity.AuctionRegisterEntity;
import ac.kr.dankook.ace.dom_t1.Model.Entity.AuctionRequestEntity;
import ac.kr.dankook.ace.dom_t1.Model.Entity.SiteuserEntity;
import ac.kr.dankook.ace.dom_t1.Model.repository.AuctionRequestRepository;

import java.time.LocalDateTime;

@RequiredArgsConstructor
@Service
public class AuctionRequestService {
    private final AuctionRequestRepository auctionRequestRepository;

    public AuctionRequestEntity createRequest(AuctionRegisterEntity auctionRegisterEntity, String content,SiteuserEntity author)
    {
        AuctionRequestEntity auctionRequestEntity = new AuctionRequestEntity();
        // AuctionRequestEntity , AuctionRegisterEntity 참조필수
        auctionRequestEntity.setContent(content); // 댓글내용 
        auctionRequestEntity.setCreateDate(LocalDateTime.now()); // 댓글 단 시간
        auctionRequestEntity.setAuctionregisterentity(auctionRegisterEntity); // 댓글을 단 등록글 
        auctionRequestEntity.setAuthor(author); // 글 등록자의 데이터 
        this.auctionRequestRepository.save(auctionRequestEntity); // 앞에서 받아온 정보들 저장하기
        return auctionRequestEntity;
    }

    
    
}
