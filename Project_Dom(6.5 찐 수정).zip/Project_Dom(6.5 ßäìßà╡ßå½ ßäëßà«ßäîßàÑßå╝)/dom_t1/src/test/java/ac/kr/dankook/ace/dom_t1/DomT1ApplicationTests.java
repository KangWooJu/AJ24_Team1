package ac.kr.dankook.ace.dom_t1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomT1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
